import javax.swing.*;
public class Dialog{
	public static void main(String args[]){
		JOptionPane.showMessageDialog(null,"I Love Java");
		
		JOptionPane.showConfirmDialog(null, "What up?", "Hey!", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE);
	}
}