
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TwoButtons extends JFrame implements ActionListener {

    JButton redButton = new JButton("Red");
    JButton grnButton = new JButton("Green");

    TwoButtons() 
    {
        setLayout(new FlowLayout());       // choose the layout manager
        redButton.addActionListener(this); // register the TwoButtons object
        grnButton.addActionListener(this); // as the listener
        redButton.setBackground(Color.red);
        grnButton.setBackground(Color.green);
        // for both Buttons.
        add(redButton);
        add(grnButton);

        setSize(200, 150);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        pack();
    }

    @Override
    public void actionPerformed(ActionEvent evt) {
        JButton currentButton = (JButton)evt.getSource();
        getContentPane().setBackground(currentButton.getBackground());
        repaint();                           // ask the system to paint the screen.
    }

    public static void main(String[] args) {
        TwoButtons demo = new TwoButtons();
    }
}
